import React, { Component } from 'react'
import PropTypes from 'prop-types'

export class user extends Component {
    static propTypes = {

    }

    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default user
